import{q as a}from"../chunks/n1utGt7g.js";export{a as start};
