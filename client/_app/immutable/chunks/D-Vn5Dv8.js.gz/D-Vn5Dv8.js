import{q as o,E as f,v as i,w as p,x as c,h,y as d}from"./B7967vnE.js";function y(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),h&&(s=d)}export{y as s};
